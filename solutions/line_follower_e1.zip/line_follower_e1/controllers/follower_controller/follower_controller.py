from controller import Robot

robot = Robot()
timestep = int(robot.getBasicTimeStep())
sensors = []
for i in range(5):
    sensor = robot.getDevice('sensor' + str(i))
    sensor.enable(timestep)
    sensors.append(sensor)

left_motor = robot.getDevice('motor.left')
left_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor = robot.getDevice('motor.right')
right_motor.setPosition(float('inf'))
right_motor.setVelocity(0.0)

left_sensor = sensors[1]
right_sensor = sensors[3]

while robot.step(timestep) != -1:
    if left_sensor.getValue() > 16 and right_sensor.getValue() > 16:
        left_motor.setVelocity(0)
        right_motor.setVelocity(0)
    else:
        left_motor.setVelocity(10)
        right_motor.setVelocity(10)
    