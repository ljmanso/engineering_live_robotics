from controller import Robot

robot = Robot()
timestep = int(robot.getBasicTimeStep())
sensors = []
for i in range(5):
    sensor = robot.getDevice('sensor' + str(i))
    sensor.enable(timestep)
    sensors.append(sensor)

left_motor = robot.getDevice('motor.left')
left_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor = robot.getDevice('motor.right')
right_motor.setPosition(float('inf'))
right_motor.setVelocity(0.0)

left_sensor = sensors[1]
right_sensor = sensors[3]
threshold = 16.
speed = 20

while robot.step(timestep) != -1:

    if left_sensor.getValue() < threshold:
        left_motor.setVelocity(speed * 0.65)
    else:
        left_motor.setVelocity(speed)

    if right_sensor.getValue() < threshold:
        right_motor.setVelocity(speed * 0.65)
    else:
        right_motor.setVelocity(speed)


