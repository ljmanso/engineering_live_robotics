from controller import Robot, Motor, LightSensor

robot = Robot()
sensors = []
for i in range(5):
    sensor = robot.getDevice('sensor'+str(i))
    sensor.enable(int(robot.getBasicTimeStep()))
    sensors.append(sensor)

left_motor = robot.getDevice('motor.left')
left_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor = robot.getDevice('motor.right')
right_motor.setPosition(float('inf'))
right_motor.setVelocity(0.0)


while robot.step(int(robot.getBasicTimeStep())) != -1:
    left_motor.setVelocity(5.)
    right_motor.setVelocity(0.)


